const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();

// This is intentionally simple: one shared PIN for the whole bureau, set as
// ACCESS_PIN in Railway's environment variables. It's enough to keep the
// sync endpoint from being open to the entire internet. Per-teller accounts
// with roles (Admin/Manager/Teller/Auditor) are a real feature to add later,
// not something to fake here — this just gates the door for now.
router.post('/login', (req, res) => {
  const { pin, device_id, name } = req.body || {};

  if (!pin || pin !== process.env.ACCESS_PIN) {
    return res.status(401).json({ error: 'Incorrect PIN' });
  }
  if (!device_id) {
    return res.status(400).json({ error: 'device_id is required' });
  }

  const token = jwt.sign(
    { device_id, user_id: name || null },
    process.env.JWT_SECRET,
    { expiresIn: '90d' }
  );

  res.json({ token });
});

module.exports = router;
