const express = require('express');
const pool = require('../db');
const router = express.Router();

// --- field mapping: client camelCase <-> db snake_case ---------------------

function toDbRow(t) {
  return {
    id: t.id,
    status: t.status,
    purpose: t.purpose || 'sale',
    teller: t.teller || null,
    customer: t.customer || null,
    currency: t.currency || null,
    amount_taken: t.amountTaken || 0,
    swap: t.swap || 0,
    rate: t.rate || 0,
    expected_ugx: t.expectedUgx || 0,
    expected_amount: t.expectedAmount || 0,
    expected_currency: t.expectedCurrency || null,
    time_out: t.timeOut || null,
    time_in: t.timeIn || null,
    delivered: t.delivered || 0,
    swap_used: t.swapUsed || 0,
    received: t.received || 0,
    fx_balance: t.fxBalance || 0,
    ugx_balance: t.ugxBalance || 0,
    brought_amount: t.broughtAmount || 0,
    brought_currency: t.broughtCurrency || null,
    remarks: t.remarks || null,
    followups: JSON.stringify(t.followups || []),
    created_at: t.created_at,
    updated_at: t.updated_at,
    deleted_at: t.deleted_at || null,
    version: t.version || 1,
    device_id: t.device_id || null,
    user_id: t.user_id || null
  };
}

function fromDbRow(r) {
  return {
    id: r.id,
    status: r.status,
    purpose: r.purpose,
    teller: r.teller,
    customer: r.customer,
    currency: r.currency,
    amountTaken: Number(r.amount_taken),
    swap: Number(r.swap),
    rate: Number(r.rate),
    expectedUgx: Number(r.expected_ugx),
    expectedAmount: Number(r.expected_amount),
    expectedCurrency: r.expected_currency,
    timeOut: r.time_out ? Number(r.time_out) : null,
    timeIn: r.time_in ? Number(r.time_in) : null,
    delivered: Number(r.delivered),
    swapUsed: Number(r.swap_used),
    received: Number(r.received),
    fxBalance: Number(r.fx_balance),
    ugxBalance: Number(r.ugx_balance),
    broughtAmount: Number(r.brought_amount),
    broughtCurrency: r.brought_currency,
    remarks: r.remarks,
    followups: r.followups || [],
    created_at: r.created_at,
    updated_at: r.updated_at,
    deleted_at: r.deleted_at,
    version: r.version,
    device_id: r.device_id,
    user_id: r.user_id,
    sync_status: 'synced',
    last_synced_at: new Date().toISOString()
  };
}

// --- GET /api/sync/pull?since=ISO_TIMESTAMP ---------------------------------
// Returns every record updated after `since` (or everything, if omitted —
// used for a device's very first sync). The client stores the returned
// server_time as its new watermark for the next pull.

router.get('/pull', async (req, res) => {
  try {
    const since = req.query.since;
    const serverTime = new Date().toISOString();

    const result = since
      ? await pool.query('SELECT * FROM trips WHERE updated_at > $1 ORDER BY updated_at ASC', [since])
      : await pool.query('SELECT * FROM trips ORDER BY updated_at ASC');

    res.json({
      trips: result.rows.map(fromDbRow),
      server_time: serverTime
    });
  } catch (err) {
    console.error('Pull failed:', err);
    res.status(500).json({ error: 'Sync pull failed' });
  }
});

// --- POST /api/sync/push -----------------------------------------------------
// Body: { trips: [ ...client records with sync metadata... ] }
// Last-write-wins by version number. If the incoming version is higher than
// (or equal to, for a first-time insert) what the server has, it's accepted.
// If the server has a newer version, the client's write is rejected and the
// server's copy is returned so the client can reconcile instead of silently
// overwriting someone else's more recent edit.

router.post('/push', async (req, res) => {
  const incoming = (req.body && req.body.trips) || [];
  if (!Array.isArray(incoming) || incoming.length === 0) {
    return res.status(400).json({ error: 'trips array is required' });
  }

  const accepted = [];
  const conflicts = [];
  const serverTime = new Date().toISOString();

  try {
    for (const t of incoming) {
      if (!t.id || !t.updated_at) continue;

      const existing = await pool.query('SELECT version FROM trips WHERE id = $1', [t.id]);

      if (existing.rows.length > 0 && existing.rows[0].version > (t.version || 1)) {
        // Server has a newer edit — don't overwrite it, send it back instead.
        const full = await pool.query('SELECT * FROM trips WHERE id = $1', [t.id]);
        conflicts.push(fromDbRow(full.rows[0]));
        continue;
      }

      const row = toDbRow(t);
      await pool.query(
        `INSERT INTO trips (
           id, status, purpose, teller, customer, currency,
           amount_taken, swap, rate, expected_ugx, expected_amount, expected_currency,
           time_out, time_in, delivered, swap_used, received, fx_balance, ugx_balance,
           brought_amount, brought_currency, remarks, followups,
           created_at, updated_at, deleted_at, version, device_id, user_id, last_synced_at
         ) VALUES (
           $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,
           $20,$21,$22,$23,$24,$25,$26,$27,$28,$29,now()
         )
         ON CONFLICT (id) DO UPDATE SET
           status=$2, purpose=$3, teller=$4, customer=$5, currency=$6,
           amount_taken=$7, swap=$8, rate=$9, expected_ugx=$10, expected_amount=$11, expected_currency=$12,
           time_out=$13, time_in=$14, delivered=$15, swap_used=$16, received=$17, fx_balance=$18, ugx_balance=$19,
           brought_amount=$20, brought_currency=$21, remarks=$22, followups=$23,
           updated_at=$25, deleted_at=$26, version=$27, device_id=$28, user_id=$29, last_synced_at=now()`,
        [
          row.id, row.status, row.purpose, row.teller, row.customer, row.currency,
          row.amount_taken, row.swap, row.rate, row.expected_ugx, row.expected_amount, row.expected_currency,
          row.time_out, row.time_in, row.delivered, row.swap_used, row.received, row.fx_balance, row.ugx_balance,
          row.brought_amount, row.brought_currency, row.remarks, row.followups,
          row.created_at, row.updated_at, row.deleted_at, row.version, row.device_id, row.user_id
        ]
      );
      accepted.push(t.id);
    }

    res.json({ accepted, conflicts, server_time: serverTime });
  } catch (err) {
    console.error('Push failed:', err);
    res.status(500).json({ error: 'Sync push failed' });
  }
});

module.exports = router;
