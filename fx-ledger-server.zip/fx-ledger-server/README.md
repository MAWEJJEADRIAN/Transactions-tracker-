# FX Ledger Server — Railway Deployment Guide

This is the sync backend for the Transaction's Reconciliation app. It gives
your offline-first app somewhere to push and pull records from once a device
has internet.

## What this server does

- `POST /api/auth/login` — exchange a shared PIN for a login token
- `GET /api/sync/pull?since=<timestamp>` — download records changed since
  the last sync
- `POST /api/sync/push` — upload local changes; the server resolves
  conflicts by version number (last-write-wins) and hands back anything it
  couldn't accept so the client can reconcile
- `GET /health` — confirms the server and database are reachable

## 1. Push this folder to GitHub

Railway deploys from a GitHub repo. Create a new repo, e.g. `fx-ledger-server`,
and push everything in this folder to it.

```bash
cd fx-ledger-server
git init
git add .
git commit -m "Initial sync backend"
git branch -M main
git remote add origin https://github.com/<your-username>/fx-ledger-server.git
git push -u origin main
```

## 2. Create the Railway project

1. Go to railway.app and sign in (GitHub login is easiest).
2. **New Project → Deploy from GitHub repo** → select `fx-ledger-server`.
3. Railway detects the Node app automatically from `package.json` — no
   Dockerfile needed.

## 3. Add a Postgres database

1. In the same Railway project: **New → Database → Add PostgreSQL**.
2. Railway automatically injects a `DATABASE_URL` environment variable into
   your app service — you don't need to copy it manually.

## 4. Set the remaining environment variables

In your app service → **Variables** tab, add:

| Variable       | Value                                                        |
|----------------|---------------------------------------------------------------|
| `JWT_SECRET`   | A long random string (see `.env.example` for how to generate one) |
| `ACCESS_PIN`   | The PIN your tellers will use to sync                        |

`DATABASE_URL` and `PORT` are already handled by Railway — don't set them
yourself.

## 5. Run the migration once

The database starts empty — the `trips` table needs to be created before the
app can use it. In Railway, open your service → **Settings → run a one-off
command** (or use the Railway CLI):

```bash
railway run npm run migrate
```

You should see `Applying 001_init.sql...` then `Migrations complete.`

## 6. Deploy and check it's alive

Railway deploys automatically after step 2. Once it's live, you'll get a
public URL like `https://fx-ledger-server-production.up.railway.app`.

Check it:
```bash
curl https://<your-app>.up.railway.app/health
# {"status":"ok","time":"..."}
```

Try logging in:
```bash
curl -X POST https://<your-app>.up.railway.app/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"pin":"<your ACCESS_PIN>","device_id":"test-device"}'
# {"token":"eyJ..."}
```

## 7. Next step

Once this is live and you've confirmed `/health` responds, share the URL
back and I'll wire the sync logic into the app itself — a "Sync Now" button
plus automatic background sync whenever the device is online, using this
exact API.

## Notes on what's deliberately simple right now

- **Auth is one shared PIN**, not per-teller accounts with roles. That's a
  real feature worth adding later, but faking it now would just be UI
  without real access control behind it.
- **CORS is wide open** (`cors()` with no restrictions). Once the app has a
  fixed domain or you're distributing it as a packaged app, tighten this in
  `server.js` to only allow that origin.
- **No file/attachment upload yet** (receipts, ID photos) — the schema and
  API only cover the transaction records themselves for now.
