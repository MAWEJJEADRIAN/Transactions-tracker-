-- FX Dispatch Ledger — cloud schema
-- Mirrors the local IndexedDB "trips" store field-for-field so sync is a
-- straightforward upsert in either direction.

CREATE TABLE IF NOT EXISTS trips (
  id                UUID PRIMARY KEY,
  status            TEXT NOT NULL,
  purpose           TEXT NOT NULL DEFAULT 'sale',
  teller            TEXT,
  customer          TEXT,
  currency          TEXT,

  amount_taken      NUMERIC DEFAULT 0,
  swap              NUMERIC DEFAULT 0,
  rate              NUMERIC DEFAULT 0,
  expected_ugx      NUMERIC DEFAULT 0,

  expected_amount   NUMERIC DEFAULT 0,
  expected_currency TEXT,

  time_out          BIGINT,
  time_in           BIGINT,

  delivered         NUMERIC DEFAULT 0,
  swap_used         NUMERIC DEFAULT 0,
  received          NUMERIC DEFAULT 0,
  fx_balance        NUMERIC DEFAULT 0,
  ugx_balance       NUMERIC DEFAULT 0,

  brought_amount    NUMERIC DEFAULT 0,
  brought_currency  TEXT,

  remarks           TEXT,
  followups         JSONB DEFAULT '[]',

  -- sync metadata
  created_at        TIMESTAMPTZ NOT NULL,
  updated_at        TIMESTAMPTZ NOT NULL,
  deleted_at        TIMESTAMPTZ,
  version           INTEGER NOT NULL DEFAULT 1,
  device_id         TEXT,
  user_id           TEXT,
  last_synced_at    TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_trips_updated_at ON trips (updated_at);
CREATE INDEX IF NOT EXISTS idx_trips_deleted_at ON trips (deleted_at);
CREATE INDEX IF NOT EXISTS idx_trips_status     ON trips (status);
